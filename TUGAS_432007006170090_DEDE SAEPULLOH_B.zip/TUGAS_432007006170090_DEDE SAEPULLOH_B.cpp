#include <iostream.h>
#include <stdio.h>
#include <conio.h>

void kodebrg(){
char kdbrg[100][100];
int no,i;
cout <<"Kode Barang :";
cin >>no;
for(i=1;i<=no;i++)
{
	cout << "Kode Barang :"<<i<<kdbrg[i]<<endl;
}
}

void namabrg(){
char nmbrg[100][100];
int no,i;
cout <<"Nama Barang :";
cin >>no;
for(i=1;i<=no;i++)
{
	cout << "Nama Barang :"<<i<<nmbrg[i]<<endl;
}
}

void satuan(){
int sat;
cout <<"Satuan :";
cin >>sat;
}

void harga(){
float hrg;
cout <<"Harga :";
cin >>hrg;
}

void qty(){
float qt;
cout <<"QTY :";
cin >>qt;
}

main(){
char pilih;
pilih='y';
while(pilih=='y')
{
cout <<"PROGRAM PENJUALAN TOKO DEDE SAEPULLOH"<<endl;
cout<<endl;
cout <<"====================================="<<endl;
   kodebrg();
	namabrg();
	satuan();
	harga();
	qty();
   cout << "Tambah Barang Lagi (y/t):";
   cin >> pilih;
   clrscr();
}
return (0);
getch();
}

