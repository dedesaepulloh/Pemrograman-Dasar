#include <iostream.h>
#include <stdio.h>
#include <conio.h>

main(){
int bnykdt,jmldt,rata;
cout << "PROGRAM MENCARI RATA-RATA \n";
cout << "-------------------------\n";
cout << "Masukan Banyak Data : ";
cin >> bnykdt;
cout << "Masukan Jumlah Data : ";
cin >> jmldt;
rata=bnykdt/jmldt;
cout << "Jadi,Rata-Ratanya Adalah " << rata << endl;
cout << "-------------------------\n";
getch();
}
